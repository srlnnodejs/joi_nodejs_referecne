# CRUD App with Node.js and Mongodb
We use Express, Mongodb and EJS

## Installation
* Clone or download zip to your machine then hit this :

yarn install

yarn start
